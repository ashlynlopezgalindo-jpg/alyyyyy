/* Pink Boutique - carrito.js */
document.addEventListener("DOMContentLoaded", () => {
  const openButton = document.getElementById("open-cart");
  const closeButton = document.getElementById("close-cart");
  const overlay = document.getElementById("cart-overlay");
  const countEl = document.getElementById("cart-count");
  const itemsEl = document.getElementById("cart-items");
  const totalEl = document.getElementById("cart-total");
  const checkoutButton = document.getElementById("checkout-button");
  const toast = document.getElementById("toast");
  const tabs = document.querySelectorAll(".category-tab");
  const products = document.querySelectorAll(".product-card");
  let cart = [];

  const money = value => new Intl.NumberFormat("es-MX", {
    style: "currency", currency: "MXN", maximumFractionDigits: 0
  }).format(value) + " MXN";

  function showToast(message) {
    if (!toast) return;
    toast.textContent = message;
    toast.classList.add("show");
    window.setTimeout(() => toast.classList.remove("show"), 2200);
  }

  function renderCart() {
    const count = cart.reduce((sum, item) => sum + item.quantity, 0);
    const total = cart.reduce((sum, item) => sum + item.price * item.quantity, 0);
    if (countEl) countEl.textContent = String(count);
    if (totalEl) totalEl.textContent = money(total);
    if (!itemsEl) return;
    if (!cart.length) {
      itemsEl.innerHTML = '<p class="empty-cart">Tu carrito está esperando algo bonito.</p>';
      return;
    }
    itemsEl.replaceChildren();
    cart.forEach(item => {
      const row = document.createElement("div");
      row.className = "cart-item";
      const details = document.createElement("div");
      const name = document.createElement("strong");
      name.textContent = item.name;
      const price = document.createElement("small");
      price.textContent = `${item.quantity} × ${money(item.price)}`;
      details.append(name, price);
      const remove = document.createElement("button");
      remove.className = "remove-item";
      remove.type = "button";
      remove.textContent = "Quitar";
      remove.addEventListener("click", () => {
        cart = cart.filter(product => product.name !== item.name);
        renderCart();
      });
      row.append(details, remove);
      itemsEl.append(row);
    });
  }

  function openCart() {
    if (overlay) { overlay.hidden = false; document.body.style.overflow = "hidden"; }
  }
  function closeCart() {
    if (overlay) { overlay.hidden = true; document.body.style.overflow = ""; }
  }
  if (openButton) openButton.addEventListener("click", openCart);
  if (closeButton) closeButton.addEventListener("click", closeCart);
  if (overlay) overlay.addEventListener("click", event => {
    if (event.target === overlay) closeCart();
  });
  document.addEventListener("keydown", event => {
    if (event.key === "Escape" && overlay && !overlay.hidden) closeCart();
  });

  document.querySelectorAll(".quick-add").forEach(button => {
    button.addEventListener("click", () => {
      const name = button.dataset.name || "Producto";
      const price = Number(button.dataset.price || 0);
      const existing = cart.find(item => item.name === name);
      if (existing) existing.quantity += 1;
      else cart.push({ name, price, quantity: 1 });
      renderCart();
      showToast(`${name} se agregó al carrito ♡`);
    });
  });

  tabs.forEach(tab => tab.addEventListener("click", () => {
    const filter = tab.dataset.filter;
    tabs.forEach(item => {
      const active = item === tab;
      item.classList.toggle("active", active);
      item.setAttribute("aria-pressed", String(active));
    });
    products.forEach(product => {
      product.hidden = filter !== "todos" && product.dataset.category !== filter;
    });
  }));

  if (checkoutButton) checkoutButton.addEventListener("click", () => {
    if (!cart.length) {
      showToast("Agrega al menos un producto antes de preparar tu pedido.");
      return;
    }
    const lines = cart.map(item => `${item.quantity} x ${item.name} — ${money(item.price * item.quantity)}`);
    const total = cart.reduce((sum, item) => sum + item.price * item.quantity, 0);
    const body = encodeURIComponent(`Resumen de pedido Pink Boutique:\n${lines.join("\n")}\nTotal: ${money(total)}\n\nPedido de demostración escolar.`);
    window.location.href = `mailto:hola@pinkboutique.mx?subject=${encodeURIComponent("Pedido de Pink Boutique")}&body=${body}`;
  });
  renderCart();
});
